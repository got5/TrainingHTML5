/**
 * @ngdoc service
 * @name sample.service:service1
 *
 * @description
 * 
 * <p> 
 * 	This service provide a function to log "hello1" in the console
 * </p>
 **/
angular.module('sample.services')
.service('service1', ['$log', function($log){

	var Service1= function(){

		/**
		* @ngdoc method
		* @name sayHello
		* @methodOf sample.service:service1
		* @description
		* <p> log 'hello1' in the console </p>
		**/		
		this.sayHello= function(){
			$log.info('hello1');
		}
	};

	return new Service1();

}]);