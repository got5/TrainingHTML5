/**
 * @ngdoc service
 * @name sample.service:service2
 *
 * @description
 * 
 * <p> 
 * 	This service provide a function to log what you want in the console
 * </p>
 **/
angular.module('sample.services')
.service('service2', ['$log', function($log){

	var Service2= function(){

		/**
		* @ngdoc method
		* @name log
		* @methodOf sample.service:service2
		* @description
		* <p> log a message in the console </p>
		*
		* @param {String} message the message to log
		**/		
		this.log= function(message){
			$log.info(message);
		}
	};

	return new Service2();

}]);