/**
 * @ngdoc overview
 * @name sample
 *
 * @description
 * <p>
 * Sample module to show an full angular project
 * and its environment.
 * </p>
 **/
angular.module('sample', ['sample.directives', 'sample.services']);