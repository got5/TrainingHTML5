angular.module('sample.directives')

 /**
 * @ngdoc directive
 * @name sdco-tools.directive:sdcoCustomEventActions
 * @restrict A
 * @scope
 *
 * @description
 * Display a "play" button which logs the message specified in the console when clicked
 *
 * @param {String} message the message to display when the element is clicked
 **/
.directive('directive2',[ 'service2',
	function(service2){
		return{
			restrict: 'E',
			scope:{
				message:'@'
			},
			replace: true,
			template:'<a class="play" ng-click="action()"></a>',
			link:function($scope,$element, $attrs){
				$scope.action= function(){ service2.log($scope.message); };
			}
		};
	}

]);