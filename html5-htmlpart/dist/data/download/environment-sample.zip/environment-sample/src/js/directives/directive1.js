angular.module('sample.directives')

 /**
 * @ngdoc directive
 * @name sdco-tools.directive:sdcoCustomEventActions
 * @restrict A
 *
 * @description
 * Display a "play" button which logs "hello1" in the console when clicked
 **/
.directive('directive1',[ 'service1',
	function(service1){
		return{
			restrict: 'E',
			template:'<div class="playContainer"><a class="play" ng-click="action()"></a>{{message}}</div>',
			replace: true,
			link:function($scope, $element, $attrs){
				$scope.action= function(){
					service1.sayHello();
					$scope.message='done';
				}
			}
		};
	}

]);