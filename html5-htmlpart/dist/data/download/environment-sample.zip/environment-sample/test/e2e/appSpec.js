describe('editor homepage', function(){

	var ptor = protractor.getInstance();

	beforeEach(function(){
		browser.get('index.html');
	});

	it('click the first play button', function(){
		var playContainer= element(by.css('.playContainer')),
			playElt= element(by.css('.play'))
		playElt.click();
		expect(playContainer.getText()).toContain('done');
	});

});