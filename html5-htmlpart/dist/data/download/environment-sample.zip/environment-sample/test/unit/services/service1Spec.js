'use strict';

describe('service sdco-editor', function(){
    //Common data

    // common vars for tests
    var service, rootScope, mockLogInstance;

    beforeEach(angular.mock.module('sample.services'));

    //Mocks
    beforeEach(function(){

        var MockLog= function(){
            this.info= jasmine.createSpy('info');
        };

        mockLogInstance= new MockLog();

        module(function($provide){
            $provide.value('$log', mockLogInstance);
        });
    });

    //Get service ref
    beforeEach(inject(function($rootScope, service1){
        rootScope= $rootScope;
        service= service1;
        rootScope.$digest();
    }));

    //Run tests
    it('Check $log.info is called ', function(){
        service.sayHello();
        expect(mockLogInstance.info).toHaveBeenCalled();
    });
 
});